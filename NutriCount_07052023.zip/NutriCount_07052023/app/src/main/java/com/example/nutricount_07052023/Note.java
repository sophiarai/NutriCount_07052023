package com.example.nutricount_07052023;

public class Note {

}
