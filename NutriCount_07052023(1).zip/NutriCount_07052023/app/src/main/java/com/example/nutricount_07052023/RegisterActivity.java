package com.example.nutricount_07052023;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    public Button buttonregister, buttonlogin, buttoninfo;
    public TextView textView;
    EditText username, email, password, repassword;
    DatabaseHelper db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        username=(EditText) findViewById(R.id.inputUsername);
        email=(EditText) findViewById(R.id.inputEmailRegister);
        password=(EditText) findViewById(R.id.inputPasswordRegister);
        repassword=(EditText) findViewById(R.id.inputConformPasswordRegister);
       buttonregister= (Button) findViewById(R.id.loginRegister);
        buttoninfo=(Button) findViewById(R.id.buttonInfo);
        textView=(TextView) findViewById(R.id.bmiTextView);
        buttonlogin=(Button) findViewById(R.id.buttonRegister);
        db=new DatabaseHelper(this);

        buttonregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user= username.getText().toString();
                String pass= password. getText().toString();
                String repass= repassword.getText().toString();

                if(user.equals("")|| pass.equals("")|| repass.equals(""))
                    Toast.makeText(RegisterActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                else{
                    if(pass.equals(repass)){
                        Boolean checkuser= db.checkusername(user);
                        if(checkuser==false){
                            Boolean insert= db.insertData(user,pass);
                            if(insert==true){
                                Toast.makeText(RegisterActivity.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                                Intent intent= new Intent(getApplicationContext(), BottomNavActivity.class);
                                startActivity(intent);
                            }else{
                                Toast.makeText(RegisterActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                            }
                        }else{
                            Toast.makeText(RegisterActivity.this, "User already exists, please sign up", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(RegisterActivity.this, "Passwords not matching", Toast.LENGTH_SHORT).show();
                    }
                }


            }});

        buttonlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }});




        buttoninfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(RegisterActivity.this, InfoActivity.class);
                startActivity(intent);
            }});


        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Starte die zweite Aktivität
                Intent intent = new Intent(RegisterActivity.this, InfoActivity.class);
                startActivity(intent);
            }
        });







    }}



