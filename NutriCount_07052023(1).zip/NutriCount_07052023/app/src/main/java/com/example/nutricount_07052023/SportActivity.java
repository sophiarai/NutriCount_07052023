package com.example.nutricount_07052023;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class SportActivity extends AppCompatActivity {

    Button btnsport;
    Button btndate;
    TextView textView2;
    TextView textViewDate;
    String[] list_sport;
    boolean[] checkedItems2;
    ArrayList<Integer> selectedsport = new ArrayList<>();

   // SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sport);

        // Laden der verbrannten Kalorien aus SharedPreferences und Anzeige
        //SharedPreferences prefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
        //int burned_Calories = prefs.getInt("burnedCalories", 0);
        //TextView burnedKcalTextView = findViewById(R.id.kcal_sport);
        //burnedKcalTextView.setText(String.format("Verbrannte Kalorien: %d kcal", burned_Calories));


        //Datum auswählen:
        textViewDate=(TextView)findViewById(R.id.textView_date2);
        btndate=(Button)findViewById(R.id.button_date);
        btndate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar kalender= Calendar.getInstance();
                SimpleDateFormat datumsFormat= new SimpleDateFormat("dd.MM.yyyy");
                textViewDate.setText(datumsFormat.format(kalender.getTime()));
            }
        });


        //Zum Auswählen von Sportarten:
        btnsport=(Button) findViewById(R.id.button_sport);
        textView2= (TextView) findViewById(R.id.textViewSport);
        list_sport=getResources().getStringArray(R.array.sport_item);
        checkedItems2= new boolean[list_sport.length];

        int[] burnedCalories = {200, 400, 600, 300, 500, 250, 350, 150, 100, 450};





        btnsport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder foodBuilder= new AlertDialog.Builder(SportActivity.this);
                foodBuilder.setTitle("Sports available in List");
                foodBuilder.setMultiChoiceItems(list_sport, checkedItems2, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int position, boolean isChecked) {
                        if(isChecked){
                            if(!selectedsport.contains(position)){
                                selectedsport.add(position);
                            }}
                        else if(selectedsport.contains(position)){
                            selectedsport.remove(position);
                        }
                    }});

                foodBuilder.setCancelable(false);
                foodBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        String item="";
                        int totalBurnedCalories = 0;  //Summiere verbrannte Kalorien für ausgewählte Sportarten
                        for( int i=0; i<selectedsport.size(); i++){
                            int position = selectedsport.get(i);
                            item= item + list_sport[selectedsport.get(i)];
                            if(i != selectedsport.size()-1){
                                item=item+", ";
                            }
                            totalBurnedCalories += burnedCalories[selectedsport.get(i)]; // Summiere verbrannte Kalorien

                        }
                        BurnedCalories.getInstance().setBurnedCalories(totalBurnedCalories);

                        textView2.setText(item);

                        // Anzeige der Summe der verbrannten Kalorien in einem neuen TextView
                        TextView burnedKcalTextView = findViewById(R.id.kcal_sport);
                        burnedKcalTextView.setText(String.format("Verbrannte Kalorien: %d kcal", totalBurnedCalories));

                       //sharedPreferences = getSharedPreferences("myPrefs", MODE_PRIVATE);
                        //SharedPreferences.Editor editor = sharedPreferences.edit();
                        //editor.putInt("burnedCalories", totalBurnedCalories);
                       // editor.apply();

                    }});

                foodBuilder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();;
                    }});

                foodBuilder.setNeutralButton("Clear all", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        for(int i=0; i<checkedItems2.length; i++){
                            checkedItems2[i]=false;
                            selectedsport.clear();
                            textView2.setText("");

                            // Setze die verbrannten Kalorien auf 0 zurück, wenn alle ausgewählten Sportarten entfernt wurden
                            TextView burnedKcalTextView = findViewById(R.id.kcal_sport);
                            burnedKcalTextView.setText("Verbrannte Kalorien: 0 kcal");
                        }}});
                AlertDialog dialog= foodBuilder.create();
                dialog.show();


}

        });




        //BottomNavigation wird in SportActivity angezeigt:
        BottomNavigationView bottomNavigationView=findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setSelectedItemId(R.id.bottom_sport);

        bottomNavigationView.setOnItemSelectedListener(item->{
            switch (item.getItemId()){
                case R.id.bottom_home:
                    startActivity(new Intent(getApplicationContext(), BottomNavActivity.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                    finish();
                    return true;
                case R.id.bottom_sport:
                    return true;
                case R.id.bottom_food:
                    startActivity(new Intent(getApplicationContext(), FoodActivity.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                    finish();
                    return true;
                case R.id.bottom_notes:
                    startActivity(new Intent(getApplicationContext(), NotesActivity.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                    finish();
                    return true;
            }
            return false;
        });
    }
}