package com.example.nutricount_07052023;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class GainedCalories extends AppCompatActivity {

    TextView gainedCaloriesTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_burned_calories);

        // Initialisiere den TextView für die Anzeige der gewonnenen Kalorien
        gainedCaloriesTextView = findViewById(R.id.textView);

        // Lade die gewonenen Kalorien aus SharedPreferences und zeige sie im TextView an
        SharedPreferences prefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
        int gainedCalories = prefs.getInt("gainedCalories", 0);
        gainedCaloriesTextView.setText(String.format("Gewonnene Kalorien: %d kcal", gainedCalories));
    }
    private static GainedCalories instance = null;
    private int gainedCalories;

    protected GainedCalories() {
        // Verhindert die Erstellung von Instanzen von außen
    }

    public static GainedCalories getInstance() {
        if (instance == null) {
            instance = new GainedCalories();
        }
        return instance;
    }

    public int getGainedCalories() {
        return gainedCalories;
    }

    public void setGainedCalories(int gainedCalories) {
        this.gainedCalories = gainedCalories;
    }
}