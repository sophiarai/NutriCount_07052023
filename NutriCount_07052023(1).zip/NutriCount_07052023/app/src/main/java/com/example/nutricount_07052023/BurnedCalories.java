package com.example.nutricount_07052023;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class BurnedCalories extends AppCompatActivity {

    TextView burnedCaloriesTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_burned_calories);

        // Initialisiere den TextView für die Anzeige der verbrannten Kalorien
        burnedCaloriesTextView = findViewById(R.id.textView);

        // Lade die verbrannten Kalorien aus SharedPreferences und zeige sie im TextView an
        SharedPreferences prefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
        int burnedCalories = prefs.getInt("burnedCalories", 0);
        burnedCaloriesTextView.setText(String.format("Verbrannte Kalorien: %d kcal", burnedCalories));
    }
    private static BurnedCalories instance = null;
    private int burnedCalories;

    protected BurnedCalories() {
        // Verhindert die Erstellung von Instanzen von außen
    }

    public static BurnedCalories getInstance() {
        if (instance == null) {
            instance = new BurnedCalories();
        }
        return instance;
    }

    public int getBurnedCalories() {
        return burnedCalories;
    }

    public void setBurnedCalories(int burnedCalories) {
        this.burnedCalories = burnedCalories;
    }
}