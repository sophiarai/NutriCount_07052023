package com.example.nutricount_07052023;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class FoodActivity extends AppCompatActivity {
    Button btnfood;
    Button btndate;
    TextView textView;

    TextView textViewDate;
    String[] list_food;
    boolean[] checkedItems;
    ArrayList<Integer> selected_food = new ArrayList<>();
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);



        //Heutiges Datum anzeigen lassen
        textViewDate = (TextView) findViewById(R.id.textView_date2);
        btndate = (Button) findViewById(R.id.button_date);

        btndate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar kalender = Calendar.getInstance();
                SimpleDateFormat datumsFormat = new SimpleDateFormat("dd.MM.yyyy");
                textViewDate.setText(datumsFormat.format(kalender.getTime()));
            }
        });


        btnfood = (Button) findViewById(R.id.button_food);
        textView = (TextView) findViewById(R.id.textViewFood);
        list_food = getResources().getStringArray(R.array.food_item);
        checkedItems = new boolean[list_food.length];

        int[] calories = {50, 30, 70, 40, 60, 20, 10, 80, 90, 100};

        btnfood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder foodBuilder = new AlertDialog.Builder(FoodActivity.this);
                foodBuilder.setTitle("Food available in List");
                foodBuilder.setMultiChoiceItems(list_food, checkedItems, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int position, boolean isChecked) {
                        if (isChecked) {
                            if (!selected_food.contains(position)) {
                                selected_food.add(position);
                            }
                        } else if (selected_food.contains(position)) {
                            selected_food.remove(position);
                        }
                    }
                });

                foodBuilder.setCancelable(false);
                foodBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        String item = "";
                        int totalCalories = 0;
                        for (int i = 0; i < selected_food.size(); i++) {
                            item = item + list_food[selected_food.get(i)];
                            if (i != selected_food.size() - 1) {
                                item = item + ", ";
                            }
                            totalCalories += calories[selected_food.get(i)];
                        }
                        GainedCalories.getInstance().setGainedCalories(totalCalories);
                        textView.setText(item);

                        // Überprüfe, ob die Kaloriengrenze von 200 kcal überschritten wurde
                        if (totalCalories > 200) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(FoodActivity.this);
                            builder.setMessage("Achtung! Die Kaloriengrenze von 200 kcal wurde überschritten.")
                                    .setPositiveButton("OK", null)
                                    .show();
                        }

                        TextView kcalTextView = findViewById(R.id.kcal_textview);
                        kcalTextView.setText(String.format("Gesamtkalorien: %d kcal", totalCalories));
                    }
                });

                foodBuilder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                        ;
                    }
                });

                foodBuilder.setNeutralButton("Clear all", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        for (int i = 0; i < checkedItems.length; i++) {
                            checkedItems[i] = false;
                            selected_food.clear();
                            textView.setText("");
                        }
                    }
                });
                AlertDialog dialog = foodBuilder.create();
                dialog.show();
            }
        });


        //BottomNavigation anzeigen in Activity
        BottomNavigationView bottomNavigationView=findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setSelectedItemId(R.id.bottom_food);

        bottomNavigationView.setOnItemSelectedListener(item->{
            switch (item.getItemId()){
                case R.id.bottom_home:
                    startActivity(new Intent(getApplicationContext(), BottomNavActivity.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                    finish();
                    return true;
                case R.id.bottom_sport:
                    startActivity(new Intent(getApplicationContext(), SportActivity.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                    finish();
                    return true;
                case R.id.bottom_food:
                    return true;
                case R.id.bottom_notes:
                    startActivity(new Intent(getApplicationContext(), NotesActivity.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                    finish();
                    return true;
            }
            return false;
        });



    }
}



